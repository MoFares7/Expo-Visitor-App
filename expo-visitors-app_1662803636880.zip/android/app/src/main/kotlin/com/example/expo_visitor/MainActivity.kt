package com.example.expo_visitor

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
