class CompanyFormData {
  final String? comapnyName;
  final String? companySpeciality;
  final String? phone;
  final int? index;

  CompanyFormData({
    this.comapnyName,
    this.companySpeciality,
    this.phone,
    this.index,
  });
}
