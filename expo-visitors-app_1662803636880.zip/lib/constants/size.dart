import 'package:flutter_screenutil/flutter_screenutil.dart';

double deffultPadding = 0.1.h;
double defaultPaddingWidth = 0.1.w;
